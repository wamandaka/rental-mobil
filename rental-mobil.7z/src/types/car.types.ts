export interface Car {
  id: number;
  name: string;
  day_rate: number;
  month_rate: number;
  image: string;
}
